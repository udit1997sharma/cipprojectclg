var mysql = require('mysql');

//first connecting with mysql

var con = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "password",
  database: "shivam"
});

con.connect(function(err) {
  if (err) throw err;
  console.log("Database Connected!");
});

module.exports = con