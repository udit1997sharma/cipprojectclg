
function GetData(){
  //This should make an AJAX call to server to get table without reloading
  var xmlhttp
  if (window.XMLHttpRequest) {
   // code for modern browsers
  xmlhttp = new XMLHttpRequest();
  } else {
   // code for old IE browsers
  xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange = function() {
   if (this.readyState == 4 && this.status == 200) {
      document.getElementById("order_table").innerHTML = this.responseText;
      }
  };
  xmlhttp.open("GET", "/fetchTable", true);
  xmlhttp.send();

}
