/*
//Still under progress : ADD LOGIN FUNCTION


function checkLogin(){

    var sessID = getCookie("SessionID")
    if(sessID == ""){



    }
    
    



}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i = 0; i < ca.length; i++) {
      var c = ca[i];
      while (c.charAt(0) == ' ') {
        c = c.substring(1);
      }
      if (c.indexOf(name) == 0) {
        return c.substring(name.length, c.length);
      }
    }
    return "";
  }


function saveUser(){

    // if all data validated, save to users database

}

function login(){

    //verify user info and authenticate the user


}

*/