const rates = {}
rates['cook'] = '200'
rates['baby_sitter'] = '300'
rates['plumber'] = '250'
rates['maid'] = '500'
rates['carpenter'] = '500'
rates['electrician'] = '300'



const nodemailer = require('nodemailer');
const express = require('express');
const app = express();
const db = require('./db')
const Cookie = require('cookie-parser') 
app.use(Cookie())

app.use(express.static('./')) //setting default dir for files

app.listen(3001,()=>{
  console.log("Server Running at localhost:3001")
})

var transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
         user: 'sankalp.15bec1182@abes.ac.in',
         pass: 'sankalp1234'
     }
 })

 function MakeEmail(mail,msg){
 const mailOptions = {
  from: 'sankalp.15bec1182@abes.ac.in', // sender address
  to: mail, // list of receivers
  subject: 'Confirmation receipt of Service order', // Subject line
  html: msg// plain text body
}

transporter.sendMail(mailOptions, function (err, info) {
  if(err)
    {console.log(err)
    console.log("Error while sending Message")}
  else{
    console.log(info);
    console.log("Message Sent successfully")
  }
});
 }

var serv
var frmdate
var todate
var dur
var mailid
var cost


app.get('/fetchTable',(req,res) =>{

var no_of_rows
var table_body = ''
var table_head = '<table class="table table-bordered"><thead><th>Order Number</th><th>Service Type</th><th>Booked Date</th><th>Duration</th><th>Cost</th><th>Generate Invoice</th></thead>'
    db.query("select service,DATE_FORMAT(from_date,'%Y-%m-%d') as frm_date,DATE_FORMAT(to_date,'%Y-%m-%d') as t_date,dur,cost from orders",(err,rows,fields)=>{
     if (err) {
            table_head = 'Error in Loading tables'
            return
          }
          var k = 0
          table_body = '<tbody>'
          no_of_rows = rows.length
          for(var k = 0;k<no_of_rows;k++){
            table_body += '<tr>'
            table_body += '<td>'+(k+1)+'</td>'
            table_body += '<td><a><strong>'+rows[k]['service']+'</strong></a></td>'
            table_body += '<td>'+rows[k]['frm_date']+'</td>'
            table_body += '<td>'+rows[k]['dur']+'Hr</td>'
            table_body += '<td>'+rows[k]['cost']+'</td>'
            table_body += '<td><a href="invoice.html">Invoice</a></td>'
            table_body += '</tr>'
          }
          table_body += '</tbody></table>'
          table_head += table_body
          res.send(table_head)

    })

})

// app.get('/loginCheck',(req,res)=>{

// console.log('Cookies: '+req.cookies)
// res.end()

// })




app.get('/hire_services',(req,res) =>{

  serv = req.query['services']
  frmdate = req.query['from_date']
  todate = req.query['to_date']
  dur = req.query['duration']
  mailid = req.query['mailid']
  var addr = req.query['addr']
  var datediff = req.query['date_diff']
  if(parseInt(datediff) == 0)
  {
    cost = parseInt(dur)*parseInt(rates[serv])
  }
  else cost = parseInt(datediff)*parseInt(dur)*parseInt(rates[serv])
  
  var qry = "INSERT INTO orders (service,from_date,to_date,mailid,dur,cost,addr) VALUES ("+"'"+serv+"'"+","+"'"+frmdate+"'"+","+"'"+todate+"'"+","+"'"+mailid+"'"+","+"'"+dur+"'"+","+"'"+cost+"'"+","+"'"+addr+"'"+")"
  db.query(qry,function (err, result) {
  if (err) {
    console.log(err)
    console.log("Error in query parsing")
    res.sendStatus(500)
  }
  else{
  var message = "Thank you for using our service. <div>Service Booked: "+serv+"<div> From Date:"+frmdate+"<div>To Date: "+todate+"<div>It will cost you: "+cost+"<h2>This is a non-reply email</h2>"
  //MakeEmail(mailid,message)     Used to send emails
  console.log("1 record inserted");
  res.redirect('/hire_services.html')
  }
  })
})